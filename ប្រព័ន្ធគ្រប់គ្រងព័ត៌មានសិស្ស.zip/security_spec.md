# Security Specification — Khmer Student Information System

## 1. Data Invariants
1. Default-deny catch-all (`/{document=**}`) blocks all unauthenticated or unmatched paths.
2. Every student document in `/students/{studentId}` and citizen document in `/citizens/{citizenId}` must carry `ownerUid` matching `request.auth.uid` on creation and immutable across updates.
3. All reads (`get` and `list`) and writes (`create`, `update`, `delete`) require an authenticated, email-verified user (`request.auth != null && request.auth.token.email_verified == true`), scoped strictly to `ownerUid == request.auth.uid` or the bootstrapped admin (`moeystong@gmail.com` with `email_verified == true`).
4. All document IDs (`studentId`, `citizenId`) must satisfy `^[a-zA-Z0-9_\-]+$` and length `<= 128`.
5. Every string field has an explicit `.size() <= maxLength` bound; numeric fields have bounded ranges; unknown shadow fields are rejected via `keys().hasOnly(...)` and `affectedKeys().hasOnly(...)`.
6. Once a student record is soft-deleted (`_deleted == true`), non-admin updates are blocked.

## 2. The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated read of `/students/S1`.
2. Unauthenticated list of `/students`.
3. Unverified email user (`email_verified: false`) creating a student in `/students/S1`.
4. Spoofed `ownerUid` on create (`/students/S1` with `ownerUid: "victim-uid"`).
5. Shadow field injection on create (`/students/S1` with extra `isAdmin: true`).
6. Cross-user `get` of another owner's `/students/S2`.
7. Unfiltered `list` query by a non-admin user without `where('ownerUid', '==', uid)`.
8. Changing `ownerUid` on update (`/students/S1` setting `ownerUid` to another UID).
9. Oversized string DoS on create (`/students/S1` with `name` length > 150).
10. Invalid path variable ID poisoning (`/students/bad.id$123` or 200-char ID).
11. Updating a soft-deleted student (`existing._deleted == true`) as a non-admin user.
12. Invalid `enrollmentStatus` enum or negative `age` on `/citizens/1`.
