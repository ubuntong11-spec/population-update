// Security rule verification matrix corresponding to security_spec.md Dirty Dozen
export const dirtyDozenCases = [
  { id: 1, op: 'get', path: '/students/S1', auth: null, expected: 'PERMISSION_DENIED' },
  { id: 2, op: 'list', path: '/students', auth: null, expected: 'PERMISSION_DENIED' },
  { id: 3, op: 'create', path: '/students/S1', auth: { uid: 'u1', email_verified: false }, expected: 'PERMISSION_DENIED' },
  { id: 4, op: 'create', path: '/students/S1', auth: { uid: 'u1', email_verified: true }, data: { ownerUid: 'u2' }, expected: 'PERMISSION_DENIED' },
  { id: 5, op: 'create', path: '/students/S1', auth: { uid: 'u1', email_verified: true }, data: { ownerUid: 'u1', isAdmin: true }, expected: 'PERMISSION_DENIED' },
  { id: 6, op: 'get', path: '/students/S2', auth: { uid: 'u1', email_verified: true }, existing: { ownerUid: 'u2' }, expected: 'PERMISSION_DENIED' },
  { id: 7, op: 'list', path: '/students', auth: { uid: 'u1', email_verified: true }, queryFilter: null, expected: 'PERMISSION_DENIED' },
  { id: 8, op: 'update', path: '/students/S1', auth: { uid: 'u1', email_verified: true }, data: { ownerUid: 'u2' }, expected: 'PERMISSION_DENIED' },
  { id: 9, op: 'create', path: '/students/S1', auth: { uid: 'u1', email_verified: true }, data: { name: 'a'.repeat(300) }, expected: 'PERMISSION_DENIED' },
  { id: 10, op: 'create', path: '/students/bad.id$123', auth: { uid: 'u1', email_verified: true }, expected: 'PERMISSION_DENIED' },
  { id: 11, op: 'update', path: '/students/S1', auth: { uid: 'u1', email_verified: true }, existing: { ownerUid: 'u1', _deleted: true }, expected: 'PERMISSION_DENIED' },
  { id: 12, op: 'create', path: '/citizens/1', auth: { uid: 'u1', email_verified: true }, data: { age: -5, enrollmentStatus: 'invalid' }, expected: 'PERMISSION_DENIED' },
];
