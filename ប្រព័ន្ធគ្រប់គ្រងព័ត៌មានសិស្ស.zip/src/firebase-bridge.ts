import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
  type User,
} from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
  fallbackAuth?: { uid?: string | null; email?: string | null }
): FirestoreErrorInfo {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid ?? fallbackAuth?.uid ?? null,
      email: auth.currentUser?.email ?? fallbackAuth?.email ?? null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId ?? null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
void testConnection();

export interface FirebaseBridge {
  config: typeof firebaseConfig;
  OperationType: typeof OperationType;
  signInWithGoogle: () => Promise<{
    uid: string;
    email: string;
    emailVerified: boolean;
    idToken: string;
    refreshToken: string;
  }>;
  signOut: () => Promise<void>;
  getFreshIdToken: (force?: boolean) => Promise<string | null>;
  getCurrentUser: () => User | null;
  handleFirestoreError: typeof handleFirestoreError;
}

declare global {
  interface Window {
    __fbBridge?: FirebaseBridge;
    __onFbAuthUser?: (user: User | null) => void;
  }
}

onAuthStateChanged(auth, (user) => {
  if (typeof window.__onFbAuthUser === 'function') {
    window.__onFbAuthUser(user);
  }
});

window.__fbBridge = {
  config: firebaseConfig,
  OperationType,
  async signInWithGoogle() {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    const idToken = await cred.user.getIdToken(true);
    return {
      uid: cred.user.uid,
      email: cred.user.email || '',
      emailVerified: cred.user.emailVerified,
      idToken,
      refreshToken: cred.user.refreshToken,
    };
  },
  async signOut() {
    await fbSignOut(auth);
  },
  async getFreshIdToken(force = false) {
    if (!auth.currentUser) return null;
    return await auth.currentUser.getIdToken(force);
  },
  getCurrentUser() {
    return auth.currentUser;
  },
  handleFirestoreError,
};
