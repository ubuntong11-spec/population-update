import vaccineListUrl from '../Vaccine list.txt?url';

export const DEFAULT_VACCINES: string[] = [
  'Covid-19',
  'Covishield',
  'Sinopharm',
  'Sinovac',
  'AstraZeneca',
  'Pfizer-BioNTech',
  'Johnson',
  'Pentavalent',
  'Tetanus',
  'Measles',
  'DTP',
  'Moderna',
  'Other...',
];

declare global {
  interface Window {
    VACCINE_LIST?: string[];
    __vaccinesReady?: Promise<void>;
    __onVaccineListReady?: () => void;
  }
}

window.VACCINE_LIST = [...DEFAULT_VACCINES];

async function loadVaccineList(): Promise<void> {
  try {
    const res = await fetch(vaccineListUrl);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw = (await res.json()) as Array<Record<string, unknown[]>>;
    if (!Array.isArray(raw)) return;

    const list: string[] = [];
    const seen = new Set<string>();
    for (let i = 0; i < raw.length; i++) {
      const entry = raw[i];
      if (!entry || typeof entry !== 'object') continue;
      const key = Object.keys(entry)[0];
      const vals = key ? entry[key] : undefined;
      if (!Array.isArray(vals) || !vals.length) continue;
      const val = String(vals[0] ?? '').trim();
      if (!val || key === '0' || val === 'បញ្ជីឈ្មោះវ៉ាក់សាំង') continue;
      if (!seen.has(val)) {
        seen.add(val);
        list.push(val);
      }
    }

    if (list.length) {
      window.VACCINE_LIST = list;
      window.dispatchEvent(new CustomEvent('vaccine-list-ready'));
      if (typeof window.__onVaccineListReady === 'function') {
        window.__onVaccineListReady();
      }
    }
  } catch (err) {
    console.warn('Failed to load Vaccine list.txt:', err);
  }
}

window.__vaccinesReady = loadVaccineList();
