import villageJsonUrl from '../cambodia village.json?url';

export type VillageTuple = [code: string, nameKh: string, nameEn: string];

interface AddrStore {
  p?: Array<[string, string]>;
  d?: Record<string, Array<[string, string]>>;
  c?: Record<string, Array<[string, string]>>;
  v?: Record<string, VillageTuple[]>;
}

declare global {
  interface Window {
    ADDR?: AddrStore;
    CAMBODIA_VILLAGES_ALL?: string[];
    VILLAGES_BY_PROVINCE?: Record<string, string[]>;
    VILLAGES_BY_DISTRICT?: Record<string, Array<{ code: string; name: string; communeCode: string }>>;
    __villagesReady?: Promise<void>;
    __onCambodiaVillagesReady?: () => void;
  }
}

const pad = (val: unknown, len: number): string => String(val ?? '').trim().padStart(len, '0');

async function loadCambodiaVillages(): Promise<void> {
  try {
    const res = await fetch(villageJsonUrl);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw = (await res.json()) as Array<Record<string, unknown[]>>;
    if (!Array.isArray(raw)) return;

    const byCommune: Record<string, VillageTuple[]> = {};
    const byDistrict: Record<string, Array<{ code: string; name: string; communeCode: string }>> = {};
    const byProvSet: Record<string, Set<string>> = {};
    const allSet = new Set<string>();

    for (let i = 0; i < raw.length; i++) {
      const entry = raw[i];
      if (!entry || typeof entry !== 'object') continue;
      const vals = Object.values(entry)[0];
      if (!Array.isArray(vals) || vals.length < 5) continue;
      if (String(vals[0]) === 'province_code') continue;

      const pv = pad(vals[0], 2);
      const dv = pad(vals[1], 4);
      const cv = pad(vals[2], 6);
      const vv = pad(vals[3], 8);
      const kh = String(vals[4] ?? '').trim();
      const en = String(vals[5] ?? '').trim();
      if (!kh) continue;

      if (!byCommune[cv]) byCommune[cv] = [];
      byCommune[cv].push([vv, kh, en]);

      if (!byDistrict[dv]) byDistrict[dv] = [];
      byDistrict[dv].push({ code: vv, name: kh, communeCode: cv });

      if (!byProvSet[pv]) byProvSet[pv] = new Set();
      byProvSet[pv].add(kh);
      allSet.add(kh);
    }

    const byProvince: Record<string, string[]> = {};
    Object.keys(byProvSet).forEach((pv) => {
      byProvince[pv] = Array.from(byProvSet[pv]).sort((a, b) => a.localeCompare(b, 'km'));
    });

    const allVillages = Array.from(allSet).sort((a, b) => a.localeCompare(b, 'km'));

    if (!window.ADDR) window.ADDR = {};
    window.ADDR.v = byCommune;
    window.VILLAGES_BY_DISTRICT = byDistrict;
    window.VILLAGES_BY_PROVINCE = byProvince;
    window.CAMBODIA_VILLAGES_ALL = allVillages;

    let dl = document.getElementById('camVillagesAll') as HTMLDataListElement | null;
    if (!dl && document.body) {
      dl = document.createElement('datalist');
      dl.id = 'camVillagesAll';
      document.body.appendChild(dl);
    }
    if (dl) {
      dl.innerHTML = allVillages
        .map((name) => `<option value="${name.replace(/"/g, '&quot;')}"></option>`)
        .join('');
    }

    window.dispatchEvent(new CustomEvent('cambodia-villages-ready'));
    if (typeof window.__onCambodiaVillagesReady === 'function') {
      window.__onCambodiaVillagesReady();
    }
  } catch (err) {
    console.warn('Failed to load cambodia village.json:', err);
  }
}

window.__villagesReady = loadCambodiaVillages();
